// src/auth/roles.enum.ts
export enum Role {
  CONSUMER = 'CONSUMER',
  VENDOR = 'VENDOR',
  DRIVER = 'DRIVER',
}
