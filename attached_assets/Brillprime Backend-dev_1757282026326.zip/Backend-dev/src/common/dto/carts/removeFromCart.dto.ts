export class RemoveFromCartDto {
  commodityId: string;
}
