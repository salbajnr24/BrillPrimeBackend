import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { PassportModule } from '@nestjs/passport';
import { AuthService } from './auth.service';
import { JwtStrategy } from 'src/config';
import { AuthController } from './auth.controller';
import { MailerService } from 'src/mailer/mailer.service';
import { UtilsServicesModule } from 'src/common/utils/utils.module';
import { CacheServicesModule } from 'src/common/utils/cache/cache.module';

@Module({
  imports: [
    PassportModule,
    UtilsServicesModule,
    CacheServicesModule,
    JwtModule.register({
      secret: process.env.JWT_SECRET || 'supersecret',
      signOptions: { expiresIn: '1d' },
    }),
  ],
  providers: [AuthService, JwtStrategy, MailerService],
  exports: [AuthService],
  controllers: [AuthController],
})
export class AuthModule {}
