// src/auth/auth.controller.ts
import { Controller, Post, Body, UseGuards, Request, UnauthorizedException } from '@nestjs/common';
import { AuthService } from './auth.service';
import {
  ChangePasswordDto,
  ForgotPasswordDto,
  ResendEmailOtpDto,
  ResetPasswordDto,
  SignInDto,
  SignUpDto,
  VerifyOtpDto,
} from 'src/common/dto';
import { JwtAuthGuard } from 'src/config';
import { Message } from 'src/common/utils';

@Controller('auth')
export class AuthController {
  constructor(private authService: AuthService) {}

  @Post('signup')
  async signup(@Body() payload: SignUpDto) {
    const data = await this.authService.register(payload);

    return {
      status: 'Success',
      message: Message.signUp,
      data: data,
    };
  }

  @Post('resend-email-otp')
  async resendEmailOtp(@Body() payload: ResendEmailOtpDto) {
    const data = await this.authService.resendEmailOtp(payload);

    return {
      status: 'Success',
      message: Message.signUp,
      data: data,
    };
  }

  @Post('verify-otp')
  async verifyOtp(@Body() payload: VerifyOtpDto) {
    const data = await this.authService.verifyOtp(payload.email, payload.otp);

    return {
      status: 'Success',
      message: Message.verifyOtp,
      data: data,
    };
  }

  @Post('signin')
  async login(@Body() payload: SignInDto) {
    const user = await this.authService.validateUser(payload);

    if (!user) {
      throw new UnauthorizedException('Invalid credentials');
    }

    const data = await this.authService.login(user);

    return {
      status: 'Success',
      message: Message.signIn,
      data: data,
    };
  }

  @Post('forgot-password')
  async forgotPassword(@Body() payload: ForgotPasswordDto) {
    const data = await this.authService.sendResetPasswordEmail(payload.email);

    return {
      status: 'Success',
      message: Message.forgotPassword,
      data: data,
    };
  }

  @Post('verify-password-reset')
  async verifyPasswordReset(@Body() verifyOtp: VerifyOtpDto) {
    const { email, otp } = verifyOtp;
    const data = await this.authService.verifyPasswordReset(email, otp);

    return {
      status: 'Success',
      message: Message.passwordResetVerified,
      data: data,
    };
  }

  @UseGuards(JwtAuthGuard) // Protect the route with JWT Guard
  @Post('reset-password')
  async resetPassword(@Request() req, @Body() resetPasswordDto: ResetPasswordDto) {
    const email = req.user['email'];
    const { password } = resetPasswordDto;
    const data = await this.authService.resetPassword(email, password);

    return {
      status: 'Success',
      message: Message.resetPassword,
      data: data,
    };
  }

  @UseGuards(JwtAuthGuard) // Protect the route with JWT Guard
  @Post('change-password')
  async changePassword(@Request() req, @Body() payload: ChangePasswordDto) {
    const userId = req.user['userId']; // Extract the userId from JWT payload
    const data = await this.authService.changePassword(userId, payload.currentPassword, payload.newPassword);

    return {
      status: 'Success',
      message: Message.changePassword,
      data: data,
    };
  }
}
