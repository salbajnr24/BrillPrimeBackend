// src/auth/auth.service.ts
import {
  BadRequestException,
  ConflictException,
  Inject,
  Injectable,
  NotFoundException,
  UnauthorizedException,
} from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import * as bcrypt from 'bcryptjs';
// import { PrismaService } from '../prisma/prisma.service';
import { MailerService } from '../mailer/mailer.service';
import { prisma } from 'src/prisma';
import { randomInt } from 'crypto';
import { ResendEmailOtpDto, SignInDto, SignUpDto, UpdateUserDto } from 'src/common/dto';
import { Role } from 'src/common';
import { ICacheService } from 'src/common/utils/cache/abstract';
import { EncryptionUtilsService, TimeUtilsService } from 'src/common/utils';
import { env } from 'src/common/env';

@Injectable()
export class AuthService {
  constructor(
    private jwtService: JwtService,
    // private prisma: PrismaService,
    private mailerService: MailerService,
    private readonly encryption: EncryptionUtilsService,
    private readonly time: TimeUtilsService,
    @Inject('Redis') private readonly cache: ICacheService,
  ) {}

  async validateUser(payload: SignInDto): Promise<any> {
    const user = await prisma.user.findUnique({ where: { email: payload.email } });

    if (!user) {
      throw new UnauthorizedException('Invalid email or password');
    }

    if (user.role.toLowerCase() !== payload.role.toLowerCase()) {
      throw new UnauthorizedException(`Email not registered as ${payload.role}`);
    }

    const isPasswordValid = await bcrypt.compare(payload.password, user.password);
    if (!isPasswordValid) {
      throw new UnauthorizedException('Invalid email or password');
    }

    return user;
  }

  async login(user: any) {
    const payload = { email: user.email, sub: user.id, role: user.role };
    return {
      access_token: this.jwtService.sign(payload),
    };
  }

  // Register a new user and send OTP for email verification
  async register(data: SignUpDto) {
    const existingUser = await prisma.user.findUnique({ where: { email: data.email } });
    if (existingUser) {
      throw new ConflictException('User with this email already exists');
    }
    const hashedPassword: string = await bcrypt.hash(data.password, 10);
    const otp = randomInt(100000, 999999).toString(); // Generate a 6-digit OTP

    // Send OTP to the user's email
    await this.mailerService.sendOtp(data.email, otp);

    // Create the user with the hashed password and OTP
    return prisma.user.create({
      data: {
        ...data,
        password: hashedPassword,
        otp,
        verified: false, // Set the verified flag to false initially
      },
    });
  }

  async resendEmailOtp(data: ResendEmailOtpDto) {
    const user = await prisma.user.findUnique({ where: { email: data.email } });

    if (!user) {
      throw new NotFoundException('User not found');
    }

    const otp = randomInt(100000, 999999).toString(); // Generate a 6-digit OTP
    await this.mailerService.sendOtp(data.email, otp);
    await prisma.user.update({ where: { email: data.email }, data: { otp } });

    return { otp };
  }
  // Verify the OTP and mark the user as verified
  async verifyOtp(email: string, otp: string) {
    const user = await prisma.user.findUnique({ where: { email } });

    if (!user) {
      throw new NotFoundException('User not found');
    }

    if (user.otp === otp) {
      // If OTP matches, mark the user as verified and clear the OTP
      await prisma.user.update({
        where: { email },
        data: {
          verified: true,
          otp: null, // Clear the OTP after successful verification
        },
      });
      return { message: 'Email verified successfully' };
    } else {
      return { message: 'Invalid OTP' };
    }
  }

  async sendResetPasswordEmail(email: string) {
    const user = await prisma.user.findUnique({ where: { email } });

    if (!user) {
      throw new NotFoundException('User not found');
    }

    const data = randomInt(100000, 999999).toString();

    const redisKey = `${email}-password-reset-otp`;
    const cachedOtp = await this.cache.get(redisKey);

    if (cachedOtp) {
      throw new ConflictException('An OTP was recently requested. Please wait 2 minutes before requesting again.');
    }

    const twoMin = this.time.convertToMilliseconds('minutes', 5);
    const hashed = await this.encryption.hash(String(data));
    await this.cache.set(redisKey, hashed, twoMin);

    await this.mailerService.sendPasswordResetOtp(email, data);

    // await prisma.user.update({
    //   where: { email },
    //   data: {
    //     otp: data,
    //   },
    // });

    return {
      message: 'Sent successfully',
      data: env.isProd ? {} : data,
    };
  }

  async verifyPasswordReset(email: string, otp: string) {
    const user = await prisma.user.findUnique({ where: { email } });

    if (!user) {
      throw new NotFoundException('User not found');
    }

    const redisKey = `${email}-password-reset-otp`;
    const redisValue = await this.cache.get(redisKey);

    if (!redisValue) {
      throw new BadRequestException('Code is invalid or expired');
    }

    const compareHash = await this.encryption.compareHash(otp, redisValue);

    if (!compareHash) {
      throw new BadRequestException('Code is invalid or expired');
    }
    await this.cache.del(redisKey);

    const payload = { email: user.email, sub: user.id, role: user.role };
    return {
      access_token: this.jwtService.sign(payload),
    };
  }

  // Reset the password after verifying the reset token
  async resetPassword(email: string, password: string) {
    const user = await prisma.user.findUnique({ where: { email } });

    if (!user) {
      throw new NotFoundException('User not found');
    }

    // If the OTP (reset token) matches, update the password
    const hashedPassword = bcrypt.hashSync(password, 10);

    await prisma.user.update({
      where: { email },
      data: {
        password: hashedPassword,
      },
    });

    const payload = { email: user.email, sub: user.id, role: user.role };
    return {
      access_token: this.jwtService.sign(payload),
    };
  }

  async changePassword(userId: string, currentPassword: string, newPassword: string) {
    const user = await prisma.user.findUnique({ where: { id: userId } });

    if (!user) {
      throw new NotFoundException('User not found');
    }

    // Check if the current password matches the stored password
    const isPasswordValid = bcrypt.compareSync(currentPassword, user.password);

    if (!isPasswordValid) {
      return { message: 'Current password is incorrect' };
    }

    // Hash the new password and update the user's password in the database
    const hashedNewPassword = bcrypt.hashSync(newPassword, 10);
    await prisma.user.update({
      where: { id: userId },
      data: { password: hashedNewPassword },
    });

    return { message: 'Password changed successfully' };
  }

  async findUserById(userId: string) {
    const user = await prisma.user.findUnique({ where: { id: userId } });
    if (!user) {
      throw new NotFoundException('User not found');
    }
    return user;
  }

  async findUserByEmail(email: string) {
    return await prisma.user.findUnique({ where: { email } });
  }

  async updateUser(userId: string, updateData: UpdateUserDto) {
    // const { email, password, ...otherData } = updateData;

    // Check if email is being updated and if it's already taken
    // if (email) {
    //   const existingUser = await prisma.user.findUnique({ where: { id: userId } });
    //   if (existingUser && existingUser.id !== userId) {
    //     throw new ConflictException('Email is already in use');
    //   }
    // }

    // Hash the new password if provided
    // let updatedPassword = undefined;
    // if (password) {
    //   updatedPassword = await bcrypt.hash(password, 10);
    // }

    // Update the user
    return await prisma.user.update({
      where: { id: userId },
      data: updateData,
    });
  }
}
