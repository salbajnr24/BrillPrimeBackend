// src/mailer/mailer.module.ts
import { Module } from '@nestjs/common';
import { MailerModule } from '@nestjs-modules/mailer';
import { HandlebarsAdapter } from '@nestjs-modules/mailer/dist/adapters/handlebars.adapter';
import { join } from 'path';
import { MailerService } from './mailer.service';

@Module({
  imports: [
    MailerModule.forRoot({
      transport: {
        // host: 'smtp-mail.outlook.com', // Replace with your SMTP host
        // port: 587,
        secure: true, // true for 465, false for other ports
        service: 'gmail',
        // auth: {
        //   user: 'kizitohorlong@outlook.com', // Replace with your email
        //   pass: 'Horlong!23', // Replace with your email password
        // },
        auth: {
          user: 'naanma4kizito@gmail.com',
          pass: 'bcnp hhbz fzwv uguc',
        },
      },
      defaults: {
        from: '"No Reply" <noreply@example.com>',
      },
      //   template: {
      //     dir: join(__dirname, '..', 'templates'),
      //     adapter: new HandlebarsAdapter(), // or new PugAdapter() or new EjsAdapter()
      //     options: {
      //       strict: false,
      //     },
      //   },
    }),
  ],
  providers: [MailerService],
  exports: [MailerService],
})
export class MailModule {}
