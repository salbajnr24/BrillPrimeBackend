// src/mailer/mailer.service.ts
import { Injectable } from '@nestjs/common';
import * as nodemailer from 'nodemailer';
import { MailerService as NestMailerService } from '@nestjs-modules/mailer';

@Injectable()
export class MailerService {
  constructor(private readonly mailerService: NestMailerService) {}

  // private transporter = nodemailer.createTransport({
  //   service: 'gmail',
  //   auth: {
  //     user: process.env.MAILER_EMAIL,
  //     pass: process.env.MAILER_PASSWORD,
  //   },
  // });

  async sendOtp(email: string, otp: string) {
    const htmlContent = '';
    await this.mailerService.sendMail({
      to: email,
      subject: 'Brill Prime Registration',
      text: `OTP: ${otp}`,
    });
    // const mailOptions = {
    //   from: process.env.MAILER_EMAIL,
    //   to: email,
    //   subject: 'Verify Your Email',
    //   text: `Your OTP is ${otp}`,
    // };
    // await this.transporter.sendMail(mailOptions);
  }

  async sendPasswordResetOtp(email: string, otp: string) {
    const htmlContent = '';
    await this.mailerService.sendMail({
      to: email,
      subject: 'Brill Prime Password reset',
      text: `OTP: ${otp}`,
    });
  }
}
