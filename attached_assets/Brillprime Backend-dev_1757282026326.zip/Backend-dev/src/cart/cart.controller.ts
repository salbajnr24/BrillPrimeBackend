// src/cart/cart.controller.ts
import { Controller, Post, Delete, Patch, Get, Param, Body, Request, UseGuards } from '@nestjs/common';
import { CartService } from './cart.service';
import { JwtAuthGuard } from 'src/config';
import { AddToCartDto, UpdateCartItemDto } from 'src/common/dto';
import { Message } from 'src/common/utils';

@Controller('cart')
@UseGuards(JwtAuthGuard)
export class CartController {
  constructor(private readonly cartService: CartService) {}

  @Post('add')
  async addToCart(@Request() req, @Body() payload: AddToCartDto) {
    const userId = req.user['userId'];
    const data = await this.cartService.addToCart(userId, payload);

    return {
      status: 'Success',
      message: Message.addToCart,
      data: data,
    };
  }

  @Delete('delete/:cartItemId')
  async removeFromCart(@Request() req, @Param('cartItemId') cartItemId: string) {
    const userId = req.user['userId'];
    const data = await this.cartService.removeFromCart(userId, cartItemId);

    return {
      status: 'Success',
      message: Message.removeFromCart,
      data: data,
    };
  }

  @Post('update-quantity')
  async updateCartItemQuantity(@Request() req, @Body() payload: UpdateCartItemDto) {
    const userId = req.user['userId'];
    const data = await this.cartService.updateCartItemQuantity(userId, payload);
    return {
      status: 'Success',
      message: Message.updateCartItemQuantity,
      data: data,
    };
  }

  @Get()
  async getCart(@Request() req) {
    const userId = req.user['userId'];
    const data = await this.cartService.getCart(userId);

    return {
      status: 'Success',
      message: Message.getCart,
      data: data,
    };
  }

  @Delete('clear')
  async clearCart(@Request() req) {
    const userId = req.user['id'];
    return this.cartService.clearCart(userId);
  }
}
