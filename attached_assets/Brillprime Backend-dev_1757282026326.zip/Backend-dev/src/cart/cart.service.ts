import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { CommoditiesService } from 'src/commodities/commodities.service';
import { AddToCartDto, RemoveFromCartDto, UpdateCartItemDto } from 'src/common/dto';
import { prisma } from 'src/prisma';
@Injectable()
export class CartService {
  // constructor(private commodityService: CommoditiesService) {}

  async addToCart(userId: string, payload: AddToCartDto) {
    const user = await prisma.user.findUnique({ where: { id: userId } });

    if (!user) {
      throw new NotFoundException('User not found');
    }

    let cart = await prisma.cart.findUnique({
      where: { userId },
      include: { items: true },
    });

    if (!cart) {
      cart = await prisma.cart.create({
        data: {
          userId,
          items: {
            create: [], // Ensure that items are initialized as an empty array
          },
        },
        include: { items: true }, // Include items in the returned result
      });
    }

    const commodity = await prisma.commodity.findUnique({
      where: { id: payload.commodityId },
    });

    if (!commodity) {
      throw new NotFoundException(`Commodity with ID ${payload.commodityId} not found`);
    }

    const existingCartItem = cart.items.find(
      (item) => item.commodityId === payload.commodityId && item.isDeleted === false,
    );

    const newVendorId = (await prisma.commodity.findFirst({ where: { id: payload.commodityId } })).vendorId;
    const uniqueVendorIds = [...new Set(cart.items.map((item) => item.vendorId))];

    console.log({ uniqueVendorIds });
    if (uniqueVendorIds.length !== 0) {
      if (!uniqueVendorIds.includes(newVendorId)) {
        throw new BadRequestException('Cant add commodities from different vendors to cart');
      }
    }

    let data;
    if (existingCartItem) {
      data = await prisma.cartItem.update({
        where: { id: existingCartItem.id },
        data: { quantity: existingCartItem.quantity + payload.quantity },
      });
    } else {
      data = await prisma.cartItem.create({
        data: {
          cartId: cart.id,
          commodityId: payload.commodityId,
          vendorId: newVendorId,
          quantity: payload.quantity,
        },
      });
    }

    return data;
  }

  // Remove an item from the cart
  async removeFromCart(userId: string, cartItemId: string) {
    const cart = await prisma.cartItem.findUnique({
      where: { id: cartItemId },
    });

    if (!cart) {
      throw new NotFoundException('Cart not found');
    }
    // const cartItem = cart.items.find((item) => item.commodityId === commodityId);
    // if (!cartItem) {
    //   throw new NotFoundException('Item not found in the cart');
    // }

    return await prisma.cartItem.delete({
      where: { id: cartItemId },
    });
  }

  // Update the quantity of an item in the cart
  async updateCartItemQuantity(userId: string, payload: UpdateCartItemDto) {
    const cartItem = await prisma.cartItem.findUnique({
      where: { id: payload.cartItemId },
    });

    if (!cartItem) {
      throw new NotFoundException('Cart item not found');
    }

    return await prisma.cartItem.update({
      where: { id: cartItem.id },
      data: { quantity: payload.quantity },
    });
  }

  // Get all items in the user's cart
  async getCart(userId: string) {
    const cart = await prisma.cart.findUnique({
      where: { userId },
      include: {
        items: {
          include: {
            commodity: true,
          },
        },
      },
    });

    if (!cart) {
      return [];
      // throw new NotFoundException('Cart not found');
    }
    const items = await prisma.cartItem.findMany({ where: { cartId: cart.id } });

    const itemsWithCommodityDetails = await Promise.all(
      items.map(async (item) => {
        const commodity = await this.getCartCommodity(item.commodityId);
        // return {
        //   ...item,
        //   commodity,
        // };
        return {
          id: item.id,
          cartId: item.cartId,
          commodityId: item.commodityId,
          quantity: item.quantity,
          commodityName: commodity.name,
          commodityDescription: commodity.description,
          commmodityPrice: commodity.price,
          unit: commodity.unit,
          imageUrl: commodity.imageUrl,
          vendorId: commodity.vendorId,
        };
      }),
    );

    return itemsWithCommodityDetails;
    // return items;
  }

  async getUserCart(userId: string) {
    const itemsWithCommodityDetails = await this.getCart(userId);
    const totalPrice = itemsWithCommodityDetails.reduce((total, item) => {
      return total + parseFloat(item.commmodityPrice) * item.quantity;
    }, 0);

    // return itemsWithCommodityDetails;
    return { totalPrice, items: itemsWithCommodityDetails };
  }

  async getOrderCart(cartId: string) {
    const cart = await prisma.cart.findUnique({
      where: { id: cartId },
      include: {
        items: {
          include: {
            commodity: true,
          },
        },
      },
    });

    if (!cart) {
      return [];
      // throw new NotFoundException('Cart not found');
    }
    const items = await prisma.cartItem.findMany({ where: { cartId: cart.id } });

    const itemsWithCommodityDetails = await Promise.all(
      items.map(async (item) => {
        const commodity = await this.getCartCommodity(item.commodityId);
        // return {
        //   ...item,
        //   commodity,
        // };
        return {
          id: item.id,
          cartId: item.cartId,
          commodityId: item.commodityId,
          quantity: item.quantity,
          commodityName: commodity.name,
          commodityDescription: commodity.description,
          commmodityPrice: commodity.price,
          unit: commodity.unit,
          imageUrl: commodity.imageUrl,
          vendorId: commodity.vendorId,
        };
      }),
    );

    return itemsWithCommodityDetails;
    // return items;
  }

  // Clear the cart
  async clearCart(id: string) {
    const cart = await prisma.cart.findFirst({
      where: { id },
    });

    if (!cart) {
      throw new NotFoundException('Cart not found');
    }

    await prisma.cartItem.deleteMany({
      where: { cartId: cart.id },
    });

    console.log('*******************CART CLEARED***************');

    return { message: 'Cart cleared' };
  }

  private async getCartCommodity(commodityId: string) {
    const commodity = await prisma.commodity.findUnique({
      where: { id: commodityId },
      select: {
        id: true,
        name: true,
        description: true,
        price: true,
        unit: true,
        vendorId: true,
        imageUrl: true,
      },
    });

    if (!commodity) {
      throw new NotFoundException(`Commodity with ID ${commodityId} not found`);
    }

    return commodity;
  }
}
