import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  const categories = [
    {
      name: 'Apparel & Clothing',
      subcategories: [
        "Men's Wear",
        "Women's Wear",
        "Kids' Clothing",
        'Footwear',
        'Accessories',
        'Activewear',
        'Lingerie',
        'Outerwear',
        'Traditional Wear',
        'Maternity Clothing',
      ],
    },
    {
      name: 'Art & Entertainment',
      subcategories: [
        'Movies & Films',
        'Music & Audio',
        'Theater & Performances',
        'Art Galleries',
        'Museums',
        'Photography',
        'Dance Studios',
        'Video Games',
        'Books & Literature',
        'Events & Festivals',
      ],
    },
    {
      name: 'Beauty, Cosmetics & Personal Care',
      subcategories: [
        'Skincare',
        'Makeup',
        'Hair Care',
        'Fragrances',
        'Bath & Body',
        'Spa Services',
        'Nail Care',
        "Men's Grooming",
        'Beauty Tools',
        'Wellness Products',
      ],
    },
    {
      name: 'Education',
      subcategories: [
        'Schools & Colleges',
        'Tutoring Services',
        'E-learning Platforms',
        'Educational Supplies',
        'Professional Training',
        'Skill Development',
        'Exam Preparation',
        'Language Schools',
        'Research Centers',
        'Libraries',
      ],
    },
    {
      name: 'Event Planner',
      subcategories: [
        'Weddings',
        'Corporate Events',
        'Birthday Parties',
        'Concerts',
        'Exhibitions',
        'Catering Services',
        'Event Rentals',
        'Floral Arrangements',
        'Photography & Videography',
        'Decorations',
      ],
    },
    {
      name: 'Finance',
      subcategories: [
        'Banking Services',
        'Investment Services',
        'Insurance',
        'Accounting & Tax',
        'Financial Advisors',
        'Loans & Mortgages',
        'Payment Solutions',
        'Forex Services',
        'Cryptocurrency',
        'Savings & Pensions',
      ],
    },
    {
      name: 'Supermarket/Convenience Store',
      subcategories: [
        'Groceries',
        'Snacks',
        'Beverages',
        'Household Items',
        'Toiletries',
        'Fresh Produce',
        'Dairy Products',
        'Cleaning Supplies',
        'Frozen Foods',
        'Pet Supplies',
      ],
    },
    {
      name: 'Hotel',
      subcategories: [
        'Accommodation',
        'Room Service',
        'Event Hosting',
        'Dining & Restaurants',
        'Spa & Wellness',
        'Concierge Services',
        'Laundry Services',
        'Fitness Centers',
        'Conference Rooms',
        'Travel Packages',
      ],
    },
    {
      name: 'Medication & Health',
      subcategories: [
        'Prescription Drugs',
        'Over-the-Counter Medicine',
        'Supplements',
        'Medical Equipment',
        'Healthcare Services',
        'Wellness Products',
        'PPE',
        'First Aid Supplies',
        'Mental Health Services',
        'Rehabilitation Services',
      ],
    },
    {
      name: 'Oil & Gas',
      subcategories: [
        'Petrol',
        'Diesel',
        'Kerosene',
        'LNG',
        'Lubricants',
        'Industrial Gases',
        'Oil Exploration',
        'Pipeline Services',
        'Fuel Distribution',
        'Gas Stations',
      ],
    },
    {
      name: 'Restaurant',
      subcategories: [
        'Fast Food',
        'Fine Dining',
        'Cafés',
        'Pizzerias',
        'Bakeries',
        'Catering Services',
        'Food Delivery',
        'Buffets',
        'Bars & Lounges',
        'Street Food',
      ],
    },
    {
      name: 'Vehicle Service',
      subcategories: [
        'Auto Repairs',
        'Car Wash',
        'Oil Change',
        'Tire Services',
        'Battery Services',
        'Vehicle Inspection',
        'Towing Services',
        'Car Rentals',
        'Auto Parts & Accessories',
        'Vehicle Maintenance',
      ],
    },
  ];

  const categories1 = [
    {
      name: 'Toll gate',
      subcategories: ['Toll ticket'],
    },
  ];

  for (const category of categories) {
    const createdCategory = await prisma.businessCategory.upsert({
      where: { name: category.name },
      update: {},
      create: {
        name: category.name,
        subcategories: {
          create: category.subcategories.map((subcategory) => ({ name: subcategory })),
        },
      },
    });

    console.log(`✅ Created category: ${createdCategory.name}`);
  }
}

main()
  .then(async () => {
    await prisma.$disconnect();
  })
  .catch(async (e) => {
    console.error(e);
    await prisma.$disconnect();
    process.exit(1);
  });
